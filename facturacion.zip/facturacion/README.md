# 📦 Facturación Backend - Spring Boot

Proyecto backend para la gestión de facturación, desarrollado en Java con Spring Boot.  
Este proyecto es parte de la prueba técnica para el cargo de Desarrollador FullStack en **Ophelia**.

---

## 🚀 Requisitos Previos
- Java JDK 17+
- Maven 3.8+
- Base de datos SQL Server (con las tablas y datos ya creados)

---

## 🛠️ Instalación del Proyecto

### 1️⃣ Ubícate en la carpeta raíz del proyecto:

```bash
cd facturacion-backend
