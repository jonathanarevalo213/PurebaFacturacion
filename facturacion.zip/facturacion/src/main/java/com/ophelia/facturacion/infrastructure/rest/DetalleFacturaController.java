package com.ophelia.facturacion.infrastructure.rest;

import com.ophelia.facturacion.application.service.FacturacionService;
import com.ophelia.facturacion.domain.model.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/detalles")
@RequiredArgsConstructor
public class DetalleFacturaController {

    private final FacturacionService service;

    @GetMapping
    public List<DetalleFactura> getAllDetalles() {
        return service.obtenerDetalles();
    }

    @PostMapping
    public DetalleFactura crearDetalle(@RequestBody DetalleFactura detalleFactura) {
        return service.guardarDetalleFactura(detalleFactura);
    }

    @PutMapping("/{id}")
    public DetalleFactura actualizarDetalle(@PathVariable int id, @RequestBody DetalleFactura detalleFactura) {
        detalleFactura.setId((long) id);
        return service.guardarDetalleFactura(detalleFactura);
    }

    @DeleteMapping("/{id}")
    public void eliminarDetalle(@PathVariable int id) {
        service.eliminarDetalleFactura(id);
    }
    @GetMapping("/{id}")
    public ResponseEntity<DetalleFactura> getDetalleById(@PathVariable int id) {
        return service.obtenerDetallePorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
