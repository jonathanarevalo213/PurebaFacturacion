package com.ophelia.facturacion.domain.model;

import lombok.*;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Factura {
    private Long id;
    private Long clienteId;
    private LocalDateTime fecha;
}
