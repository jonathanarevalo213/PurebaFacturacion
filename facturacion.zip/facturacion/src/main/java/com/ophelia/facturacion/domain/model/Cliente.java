package com.ophelia.facturacion.domain.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Cliente {
    private Long id;
    private String nombre;
    private int edad;
    private String correo;
}
