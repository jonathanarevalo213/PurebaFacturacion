package com.ophelia.facturacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.ophelia.facturacion")
public class FacturacionApplication {
	public static void main(String[] args) {
		SpringApplication.run(FacturacionApplication.class, args);
	}
}


