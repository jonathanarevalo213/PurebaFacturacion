package com.ophelia.facturacion.domain.repository;

import com.ophelia.facturacion.domain.model.DetalleFactura;
import java.util.List;
import java.util.Optional;

public interface DetalleFacturaRepository {
    List<DetalleFactura> findAll();
    Optional<DetalleFactura> findById(int id);
    DetalleFactura save(DetalleFactura detalleFactura);
    void deleteById(int id);
}
