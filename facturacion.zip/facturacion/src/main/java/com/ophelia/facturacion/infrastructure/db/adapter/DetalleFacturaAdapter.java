package com.ophelia.facturacion.infrastructure.db.adapter;

import com.ophelia.facturacion.domain.model.DetalleFactura;
import com.ophelia.facturacion.domain.repository.DetalleFacturaRepository;
import com.ophelia.facturacion.infrastructure.db.entity.DetalleFacturaEntity;
import com.ophelia.facturacion.infrastructure.db.repository.JpaDetalleFacturaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class DetalleFacturaAdapter implements DetalleFacturaRepository {

    private final JpaDetalleFacturaRepository repository;

    @Override
    public List<DetalleFactura> findAll() {
        return repository.findAll().stream()
                .map(this::toDomain)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<DetalleFactura> findById(int id) {
        return repository.findById((long) id)
                .map(this::toDomain);
    }

    @Override
    public DetalleFactura save(DetalleFactura detalleFactura) {
        DetalleFacturaEntity entity = new DetalleFacturaEntity(null, detalleFactura.getFacturaId(), detalleFactura.getProductoId(), detalleFactura.getCantidad(), detalleFactura.getPrecioUnitario());
        DetalleFacturaEntity saved = repository.save(entity);
        return toDomain(saved);
    }

    @Override
    public void deleteById(int id) {
        repository.deleteById((long) id);
    }

    private DetalleFactura toDomain(DetalleFacturaEntity entity) {
        return new DetalleFactura(entity.getId(), entity.getFacturaId(), entity.getProductoId(), entity.getCantidad(), entity.getPrecioUnitario());
    }
}
