package com.ophelia.facturacion.domain.repository;

import com.ophelia.facturacion.domain.model.Producto;
import java.util.List;
import java.util.Optional;

public interface ProductoRepository {
    List<Producto> findAll();
    Optional<Producto> findById(int id);
    Producto save(Producto producto);
    void deleteById(int id);
}
