package com.ophelia.facturacion.infrastructure.db.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "DetalleFactura")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DetalleFacturaEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "factura_id")
    private Long facturaId;

    @Column(name = "producto_id")
    private Long productoId;

    private int cantidad;

    @Column(name = "precio_unitario")
    private double precioUnitario;
}
