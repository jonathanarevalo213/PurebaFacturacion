package com.ophelia.facturacion.infrastructure.db.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "Factura")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FacturaEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "cliente_id") // Asegúrate que en la DB la columna es cliente_id, no clienteId
    private ClienteEntity cliente;

    private LocalDateTime fecha;
}
