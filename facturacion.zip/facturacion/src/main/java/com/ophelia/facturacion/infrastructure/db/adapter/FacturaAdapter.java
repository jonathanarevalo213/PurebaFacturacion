package com.ophelia.facturacion.infrastructure.db.adapter;

import com.ophelia.facturacion.domain.model.Factura;
import com.ophelia.facturacion.domain.repository.FacturaRepository;
import com.ophelia.facturacion.infrastructure.db.entity.ClienteEntity;
import com.ophelia.facturacion.infrastructure.db.entity.FacturaEntity;
import com.ophelia.facturacion.infrastructure.db.repository.JpaFacturaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class FacturaAdapter implements FacturaRepository {

    private final JpaFacturaRepository repository;

    @Override
    public List<Factura> findAll() {
        return repository.findAll().stream()
                .map(this::toDomain)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<Factura> findById(int id) {
        return repository.findById((long) id)
                .map(this::toDomain);
    }

    @Override
    public Factura save(Factura factura) {
        ClienteEntity cliente = new ClienteEntity();
        cliente.setId(factura.getClienteId());

        FacturaEntity entity = new FacturaEntity(null, cliente, factura.getFecha());
        FacturaEntity saved = repository.save(entity);
        return toDomain(saved);
    }

    @Override
    public void deleteById(int id) {
        repository.deleteById((long) id);
    }

    private Factura toDomain(FacturaEntity entity) {
        return new Factura(entity.getId(), entity.getCliente().getId(), entity.getFecha());
    }
}
