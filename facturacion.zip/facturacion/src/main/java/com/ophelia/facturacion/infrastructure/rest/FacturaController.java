package com.ophelia.facturacion.infrastructure.rest;

import com.ophelia.facturacion.application.service.FacturacionService;
import com.ophelia.facturacion.domain.model.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/facturas")
@RequiredArgsConstructor
public class FacturaController {

    private final FacturacionService service;

    @GetMapping
    public List<Factura> getAllFacturas() {
        return service.obtenerFacturas();
    }

    @PostMapping
    public Factura crearFactura(@RequestBody Factura factura) {
        return service.guardarFactura(factura);
    }

    @PutMapping("/{id}")
    public Factura actualizarFactura(@PathVariable int id, @RequestBody Factura factura) {
        factura.setId((long) id);
        return service.guardarFactura(factura);
    }

    @DeleteMapping("/{id}")
    public void eliminarFactura(@PathVariable int id) {
        service.eliminarFactura(id);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Factura> getFacturaById(@PathVariable int id) {
        return service.obtenerFacturaPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}

