package com.ophelia.facturacion.domain.repository;

import com.ophelia.facturacion.domain.model.Cliente;
import java.util.List;
import java.util.Optional;

public interface ClienteRepository {

    List<Cliente> findAll();

    Optional<Cliente> findById(int id);

    Cliente save(Cliente cliente);

    void deleteById(int id);
}

