package com.ophelia.facturacion.infrastructure.rest;

import com.ophelia.facturacion.application.service.FacturacionService;
import com.ophelia.facturacion.domain.model.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/clientes")
@RequiredArgsConstructor
public class ClienteController {

    private final FacturacionService service;

    @GetMapping
    public List<Cliente> getAllClientes() {
        return service.obtenerClientes();
    }
    @GetMapping("/{id}")
    public ResponseEntity<Cliente> getClienteById(@PathVariable int id) {
        return service.obtenerClientePorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    @PostMapping
    public Cliente crearCliente(@RequestBody Cliente cliente) {
        return service.guardarCliente(cliente);
    }

    @PutMapping("/{id}")
    public Cliente actualizarCliente(@PathVariable int id, @RequestBody Cliente cliente) {
        cliente.setId((long) id);
        return service.guardarCliente(cliente);
    }

    @DeleteMapping("/{id}")
    public void eliminarCliente(@PathVariable int id) {
        service.eliminarCliente(id);
    }
}
