package com.ophelia.facturacion.domain.repository;

import com.ophelia.facturacion.domain.model.Factura;
import java.util.List;
import java.util.Optional;

public interface FacturaRepository {
    List<Factura> findAll();
    Optional<Factura> findById(int id);
    Factura save(Factura factura);
    void deleteById(int id);
}
