package com.ophelia.facturacion.infrastructure.db.adapter;

import com.ophelia.facturacion.domain.model.Producto;
import com.ophelia.facturacion.domain.repository.ProductoRepository;
import com.ophelia.facturacion.infrastructure.db.entity.ProductoEntity;
import com.ophelia.facturacion.infrastructure.db.repository.JpaProductoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class ProductoAdapter implements ProductoRepository {

    private final JpaProductoRepository repository;

    @Override
    public List<Producto> findAll() {
        return repository.findAll().stream()
                .map(this::toDomain)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<Producto> findById(int id) {
        return repository.findById((long) id)
                .map(this::toDomain);
    }

    @Override
    public Producto save(Producto producto) {
        ProductoEntity entity;

        if (producto.getId() != null && producto.getId() > 0) {
            entity = repository.findById(producto.getId())
                    .orElseThrow(() -> new RuntimeException("Producto no encontrado con id " + producto.getId()));
            entity.setNombre(producto.getNombre());
            entity.setPrecio(producto.getPrecio());
            entity.setStock(producto.getStock());
        } else {
            entity = new ProductoEntity(null, producto.getNombre(), producto.getPrecio(), producto.getStock());
        }

        ProductoEntity saved = repository.save(entity);
        return toDomain(saved);
    }


    @Override
    public void deleteById(int id) {
        repository.deleteById((long) id);
    }

    private Producto toDomain(ProductoEntity entity) {
        return new Producto(entity.getId(), entity.getNombre(), entity.getPrecio(), entity.getStock());
    }
}
