package com.ophelia.facturacion.domain.model;

import lombok.*;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DetalleFactura {
    private Long id;
    private Long facturaId;
    private Long productoId;
    private int cantidad;
    private double precioUnitario;
}