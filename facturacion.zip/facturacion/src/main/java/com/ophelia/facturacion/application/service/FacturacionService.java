
package com.ophelia.facturacion.application.service;

import com.ophelia.facturacion.domain.model.*;
import com.ophelia.facturacion.domain.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class FacturacionService {
    private final ClienteRepository clienteRepository;
    private final ProductoRepository productoRepository;
    private final FacturaRepository facturaRepository;
    private final DetalleFacturaRepository detalleFacturaRepository;

    public List<Cliente> obtenerClientes() { return clienteRepository.findAll(); }
    public List<Producto> obtenerProductos() { return productoRepository.findAll(); }
    public List<Factura> obtenerFacturas() { return facturaRepository.findAll(); }
    public List<DetalleFactura> obtenerDetalles() { return detalleFacturaRepository.findAll(); }


    public Cliente guardarCliente(Cliente cliente) { return clienteRepository.save(cliente); }
    public Producto guardarProducto(Producto producto) { return productoRepository.save(producto); }
    public Factura guardarFactura(Factura factura) { return facturaRepository.save(factura); }
    public DetalleFactura guardarDetalleFactura(DetalleFactura detalleFactura) { return detalleFacturaRepository.save(detalleFactura); }

    public void eliminarCliente(int id) { clienteRepository.deleteById(id); }
    public void eliminarProducto(int id) { productoRepository.deleteById(id); }
    public void eliminarFactura(int id) { facturaRepository.deleteById(id); }
    public void eliminarDetalleFactura(int id) { detalleFacturaRepository.deleteById(id); }

    public Optional<Cliente> obtenerClientePorId(int id) {return clienteRepository.findById(id);}
    public Optional<Producto> obtenerProductoPorId(int id) {return productoRepository.findById(id);}
    public Optional<Factura> obtenerFacturaPorId(int id) {return facturaRepository.findById(id);}
    public Optional<DetalleFactura> obtenerDetallePorId(int id) {return detalleFacturaRepository.findById(id);}


}
