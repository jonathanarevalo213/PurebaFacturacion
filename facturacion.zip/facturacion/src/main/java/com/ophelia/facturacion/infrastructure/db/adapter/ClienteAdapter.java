package com.ophelia.facturacion.infrastructure.db.adapter;

import com.ophelia.facturacion.domain.model.Cliente;
import com.ophelia.facturacion.domain.repository.ClienteRepository;
import com.ophelia.facturacion.infrastructure.db.entity.ClienteEntity;
import com.ophelia.facturacion.infrastructure.db.repository.JpaClienteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class ClienteAdapter implements ClienteRepository {

    private final JpaClienteRepository repository;

    @Override
    public List<Cliente> findAll() {
        return repository.findAll().stream()
                .map(this::toDomain)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<Cliente> findById(int id) {
        return repository.findById((long) id)
                .map(this::toDomain);
    }

    @Override
    public Cliente save(Cliente cliente) {
        ClienteEntity entity = new ClienteEntity();
        entity.setId(cliente.getId());
        entity.setNombre(cliente.getNombre());
        entity.setEdad(cliente.getEdad());
        entity.setCorreo(cliente.getCorreo());
        ClienteEntity saved = repository.save(entity);
        return toDomain(saved);
    }

    @Override
    public void deleteById(int id) {
        repository.deleteById((long) id);
    }

    private Cliente toDomain(ClienteEntity entity) {
        return new Cliente(entity.getId(), entity.getNombre(), entity.getEdad(), entity.getCorreo());
    }
}
