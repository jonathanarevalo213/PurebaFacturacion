# 📦 Facturación Frontend - Angular  

Aplicación web para la gestión de facturación desarrollada en Angular.  
Este proyecto es parte de la prueba técnica para el cargo de Desarrollador.

---

## 🚀 Requisitos Previos  
- Node.js 18+  
- Angular CLI instalado globalmente

```bash
npm install -g @angular/cli
