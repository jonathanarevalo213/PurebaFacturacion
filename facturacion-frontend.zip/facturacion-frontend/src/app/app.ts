import { Component } from '@angular/core';
import { RouterOutlet, RouterModule } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterModule],
  template: `
    <nav style="padding: 10px; background-color: #f0f0f0;">
      <a routerLink="/clientes" routerLinkActive="active" style="margin-right: 10px;">Clientes</a>
      <a routerLink="/productos" routerLinkActive="active" style="margin-right: 10px;">Productos</a>
      <a routerLink="/facturas" routerLinkActive="active" style="margin-right: 10px;">Facturas</a>
      <a routerLink="/detalles-factura" routerLinkActive="active">Detalles Factura</a>

    </nav>
    <router-outlet></router-outlet>
  `,
  styles: [`
    nav a {
      text-decoration: none;
      color: #333;
      font-weight: bold;
    }
    nav a.active {
      color: blue;
    }
  `]
})
export class App {}
