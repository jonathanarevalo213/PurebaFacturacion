import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ClienteService } from '../../../core/services/cliente.service';
import { Cliente } from '../../../core/models/cliente.model';


@Component({
  selector: 'app-clientes-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './clientes-form.html',
  styleUrls: ['./clientes-form.scss']
})
export class ClientesForm {
  clienteForm: FormGroup;
  idCliente?: number;

  constructor(
    private fb: FormBuilder,
    private clienteService: ClienteService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.clienteForm = this.fb.group({
      nombre: ['', Validators.required],
      edad: ['', Validators.required],
      correo: ['', [Validators.required, Validators.email]],
    });

    this.route.params.subscribe(params => {
      if (params['id']) {
        this.idCliente = +params['id'];
        this.clienteService.getById(this.idCliente).subscribe(cliente => {
          this.clienteForm.patchValue(cliente);
        });
      }
    });
  }

  guardar(): void {
    const cliente: Cliente = this.clienteForm.value;
    if (this.idCliente) {
      this.clienteService.update(this.idCliente, cliente).subscribe(() => {
        alert('Cliente actualizado');
        this.router.navigate(['/clientes']);
      });
    } else {
      this.clienteService.create(cliente).subscribe(() => {
        alert('Cliente creado correctamente');
        this.router.navigate(['/clientes']);
      });
    }
  }
}
