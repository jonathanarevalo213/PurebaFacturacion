import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { Cliente } from '../../../core/models/cliente.model';
import { ClienteService } from '../../../core/services/cliente.service';

@Component({
  selector: 'app-clientes-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './clientes-list.html',
})

export class ClientesList implements OnInit {
  clientes: Cliente[] = [];

  constructor(private clienteService: ClienteService, private router: Router) {}

  ngOnInit(): void {
    this.cargarClientes();
  }

  cargarClientes(): void {
    this.clienteService.getAll().subscribe((data) => {
      this.clientes = data;
    });
  }

  eliminar(id: number): void {
    this.clienteService.delete(id).subscribe(() => {
      alert('Cliente eliminado correctamente');
      this.cargarClientes();
    });
  }

  editar(id: number) {
  this.router.navigate(['/clientes/editar', id]);
}
}
