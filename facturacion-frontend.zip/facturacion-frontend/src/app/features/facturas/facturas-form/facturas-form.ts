import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { FacturaService } from '../../../core/services/factura.service';
import { Factura } from '../../../core/models/factura.model';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-facturas-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './facturas-form.html',
})
export class FacturasForm implements OnInit {
  facturaForm: FormGroup;
  idFactura?: number;

  constructor(
    private fb: FormBuilder,
    private facturaService: FacturaService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.facturaForm = this.fb.group({
      clienteId: [0, Validators.required],
      fecha: ['', Validators.required],  // ← Aquí debe ser string, no Date.
    });
  }

  ngOnInit(): void {
  this.idFactura = this.route.snapshot.params['id'];
  if (this.idFactura) {
    this.facturaService.getById(this.idFactura).subscribe(data => {
      this.facturaForm.patchValue({
        clienteId: data.clienteId,
        fecha: new Date(data.fecha).toISOString().substring(0, 10), // formato yyyy-MM-dd para <input type="date">
      });
    });
  }
}


guardar(): void {
  const factura: Factura = this.facturaForm.value;

  // Convierte string '2025-07-18' en '2025-07-18T00:00:00'
  factura.fecha = factura.fecha + 'T00:00:00';

  if (this.idFactura) {
    this.facturaService.update(this.idFactura, factura).subscribe(() => {
      alert('Factura actualizada correctamente');
      this.router.navigate(['/facturas']);
    });
  } else {
    this.facturaService.create(factura).subscribe(() => {
      alert('Factura guardada correctamente');
      this.router.navigate(['/facturas']);
    });
  }
}


}