import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FacturasList } from './facturas-list';

describe('FacturasList', () => {
  let component: FacturasList;
  let fixture: ComponentFixture<FacturasList>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FacturasList]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FacturasList);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
