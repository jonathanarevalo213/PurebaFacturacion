import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FacturaService } from '../../../core/services/factura.service';
import { Factura } from '../../../core/models/factura.model';


@Component({
  selector: 'app-facturas-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './facturas-list.html',
})
export class FacturasList implements OnInit {
  facturas: Factura[] = [];

  constructor(private facturaService: FacturaService, private router: Router) {}

  ngOnInit(): void {
    this.cargarFacturas();
  }

  cargarFacturas(): void {
    this.facturaService.getAll().subscribe((data) => {
      this.facturas = data;
    });
  }

  eliminar(id: number): void {
    this.facturaService.delete(id).subscribe(() => {
      alert('Factura eliminada correctamente');
      this.cargarFacturas();
    });
  }

  editar(id: number): void {
    this.router.navigate(['/facturas/editar', id]);
  }
}
