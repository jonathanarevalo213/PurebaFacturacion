import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ProductoService } from '../../../core/services/producto.service';
import { Producto } from '../../../core/models/producto.model';

@Component({
  selector: 'app-productos-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './productos-form.html',
  styleUrls: ['./productos-form.scss']
})
export class ProductosForm {
  productoForm: FormGroup;
  idProducto?: number;

  constructor(
    private fb: FormBuilder,
    private productoService: ProductoService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.productoForm = this.fb.group({
      nombre: ['', Validators.required],
      precio: ['', Validators.required],
      stock: ['', Validators.required],
    });

    this.route.params.subscribe(params => {
      if (params['id']) {
        this.idProducto = +params['id'];
        this.productoService.getById(this.idProducto).subscribe(producto => {
          this.productoForm.patchValue({
            nombre: producto.nombre,
            precio: producto.precio,
            stock: producto.stock
          });
        });
      }
    });
  }

  guardar(): void {
    const producto: Producto = this.productoForm.value;

    if (this.idProducto) {
      this.productoService.update(this.idProducto, producto).subscribe(() => {
        alert('Producto actualizado');
        this.router.navigate(['/productos']);
      });
    } else {
      this.productoService.create(producto).subscribe(() => {
        alert('Producto creado correctamente');
        this.router.navigate(['/productos']);
      });
    }
  }
}
