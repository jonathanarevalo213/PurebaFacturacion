import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { Producto } from '../../../core/models/producto.model';
import { ProductoService } from '../../../core/services/producto.service';

@Component({
  selector: 'app-productos-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './productos-list.html',
})
export class ProductosList implements OnInit {
  productos: Producto[] = [];

  constructor(private productoService: ProductoService, private router: Router) {}

  ngOnInit(): void {
    this.cargarProductos();
  }

  cargarProductos(): void {
    this.productoService.getAll().subscribe((data) => {
      this.productos = data;
    });
  }

  eliminar(id: number): void {
    this.productoService.delete(id).subscribe(() => {
      alert('Producto eliminado correctamente');
      this.cargarProductos();
    });
  }

  editar(id: number): void {
    this.router.navigate(['/productos/editar', id]);
  }
}
