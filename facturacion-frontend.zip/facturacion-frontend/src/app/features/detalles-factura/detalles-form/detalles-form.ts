import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { DetalleFacturaService } from '../../../core/services/detalle-factura.service';
import { DetalleFactura } from '../../../core/models/detalle-factura.model';


@Component({
  selector: 'app-detalles-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './detalles-form.html',
})
export class DetallesForm implements OnInit {
  detalleForm: FormGroup;
  idDetalle?: number;

  constructor(
    private fb: FormBuilder,
    private detalleService: DetalleFacturaService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.detalleForm = this.fb.group({
      facturaId: [0, Validators.required],
      productoId: [0, Validators.required],
      cantidad: [1, Validators.required],
      precioUnitario: [0, Validators.required],
    });
  }

  ngOnInit(): void {
    this.idDetalle = this.route.snapshot.params['id'];
    if (this.idDetalle) {
      this.detalleService.getById(this.idDetalle).subscribe((data) => {
        this.detalleForm.patchValue({
          facturaId: data.facturaId,
          productoId: data.productoId,
          cantidad: data.cantidad,
          precioUnitario: data.precioUnitario,
        });
      });
    }
  }

  guardar(): void {
    const detalle: DetalleFactura = this.detalleForm.value;
    if (this.idDetalle) {
      this.detalleService.update(this.idDetalle, detalle).subscribe(() => {
        alert('Detalle actualizado correctamente');
        this.router.navigate(['/detalles-factura']);
      });
    } else {
      this.detalleService.create(detalle).subscribe(() => {
        alert('Detalle guardado correctamente');
        this.router.navigate(['/detalles-factura']);
      });
    }
  }
}
