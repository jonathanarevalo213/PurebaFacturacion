import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetallesForm } from './detalles-form';

describe('DetallesForm', () => {
  let component: DetallesForm;
  let fixture: ComponentFixture<DetallesForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DetallesForm]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DetallesForm);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
