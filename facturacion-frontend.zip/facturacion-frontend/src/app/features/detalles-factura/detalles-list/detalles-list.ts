import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { DetalleFactura } from '../../../core/models/detalle-factura.model';
import { DetalleFacturaService } from '../../../core/services/detalle-factura.service';


@Component({
  selector: 'app-detalles-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './detalles-list.html',
})
export class DetallesList implements OnInit {
  detalles: DetalleFactura[] = [];

  constructor(private detalleService: DetalleFacturaService, private router: Router) {}

  ngOnInit(): void {
    this.cargarDetalles();
  }

  cargarDetalles(): void {
    this.detalleService.getAll().subscribe((data) => {
      this.detalles = data;
    });
  }

  eliminar(id: number): void {
    this.detalleService.delete(id).subscribe(() => {
      alert('Detalle eliminado correctamente');
      this.cargarDetalles();
    });
  }
  editar(id: number): void {
  this.router.navigate(['/detalles-factura/editar', id]);
}

}
