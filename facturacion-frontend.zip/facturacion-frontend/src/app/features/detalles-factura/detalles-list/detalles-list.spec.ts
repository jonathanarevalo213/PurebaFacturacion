import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetallesList } from './detalles-list';

describe('DetallesList', () => {
  let component: DetallesList;
  let fixture: ComponentFixture<DetallesList>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DetallesList]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DetallesList);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
