import { Routes } from '@angular/router';
import { ClientesList } from './features/clientes/clientes-list/clientes-list';
import { ClientesForm } from './features/clientes/clientes-form/clientes-form';
import { ProductosList } from './features/productos/productos-list/productos-list';
import { ProductosForm } from './features/productos/productos-form/productos-form';
import { FacturasList } from './features/facturas/facturas-list/facturas-list';
import { FacturasForm } from './features/facturas/facturas-form/facturas-form';
import { DetallesList } from './features/detalles-factura/detalles-list/detalles-list';
import { DetallesForm } from './features/detalles-factura/detalles-form/detalles-form';

export const routes: Routes = [
  { path: 'clientes', component: ClientesList },
  { path: 'clientes/nuevo', component: ClientesForm },
  { path: 'clientes/editar/:id', component: ClientesForm },
  { path: 'productos', component: ProductosList },
  { path: 'productos/nuevo', component: ProductosForm },
  { path: 'productos/editar/:id', component: ProductosForm },
  { path: 'facturas', component: FacturasList },
  { path: 'facturas/nuevo', component: FacturasForm },
  { path: 'facturas/editar/:id', component: FacturasForm },
  { path: 'detalles-factura', component: DetallesList },
  { path: 'detalles-factura/nuevo', component: DetallesForm },
  { path: 'detalles-factura/editar/:id', component: DetallesForm },
  { path: '**', redirectTo: 'clientes' },
];
