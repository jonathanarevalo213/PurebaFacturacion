import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DetalleFactura } from '../models/detalle-factura.model';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class DetalleFacturaService {
  private apiUrl = 'http://localhost:8080/api/detalles';

  constructor(private http: HttpClient) {}

  getAll(): Observable<DetalleFactura[]> {
    return this.http.get<DetalleFactura[]>(this.apiUrl);
  }

  getById(id: number): Observable<DetalleFactura> {
    return this.http.get<DetalleFactura>(`${this.apiUrl}/${id}`);
  }

  create(detalle: DetalleFactura): Observable<DetalleFactura> {
    return this.http.post<DetalleFactura>(this.apiUrl, detalle);
  }

  update(id: number, detalle: DetalleFactura): Observable<DetalleFactura> {
    return this.http.put<DetalleFactura>(`${this.apiUrl}/${id}`, detalle);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
