export interface Factura {
  id?: number;
  clienteId: number;
  fecha: string;
}
