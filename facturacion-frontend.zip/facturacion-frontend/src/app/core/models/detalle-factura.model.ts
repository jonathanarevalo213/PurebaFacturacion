export interface DetalleFactura {
  id?: number;
  facturaId: number;
  productoId: number;
  cantidad: number;
  precioUnitario: number;
}
